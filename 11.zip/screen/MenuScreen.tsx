import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function MenuScreen() {
  return (
    <View>
      <Text>444444444444</Text>
    </View>
  )
}

const styles = StyleSheet.create({})
import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function JuegoScreen() {
  return (
    <View>
      <Text>JuegoScreen</Text>
    </View>
  )
}

const styles = StyleSheet.create({})
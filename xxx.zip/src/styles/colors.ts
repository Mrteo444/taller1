export const Colors = {
    primary: "#05216B",
    secondary: "#84cc16",
    tertiary: "#eab308",
    background: "#ecfccb",
  };